-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 05, 2022 at 04:52 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tutor`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_courseadd`
--

CREATE TABLE `tbl_courseadd` (
  `cid` int(20) NOT NULL,
  `cname` varchar(20) NOT NULL,
  `subcode` varchar(50) NOT NULL,
  `cstart` varchar(20) NOT NULL,
  `cend` varchar(20) NOT NULL,
  `fees` int(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  `status` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_courseadd`
--

INSERT INTO `tbl_courseadd` (`cid`, `cname`, `subcode`, `cstart`, `cend`, `fees`, `description`, `status`) VALUES
(14, 'Mathematics', 'maths IV20 ', '2021-05-01', '2022-08-11', 2000, 'Course for 6th students', 1),
(15, 'english', 'english1101', '2022-06-03', '2022-10-30', 2000, 'Course for 6th students', 1),
(17, '   english', '1101', '2022-10-05', '2022-10-19', 2000, 'english', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE `tbl_login` (
  `logid` int(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `role` int(11) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`logid`, `email`, `role`, `password`, `status`) VALUES
(1, 'admin@gmail.com', 0, 'admins', '0'),
(24, 'athirabiju42469@gmail.com', 0, '4e733d43a443a1366493065fd3683a52', '0'),
(25, 'manyamadhu@gmail.com', 0, '76ccd85e123f03a2783d457d8f293ccd', '0'),
(26, 'athirabiju4246@gmail.com', 0, '38e3822151b75d939731758afc2179cf', '0'),
(27, 'athirabiju4246@gmail.com', 0, 'athira123', ''),
(28, 'akhila@gmail.com', 0, 'akila123', ''),
(29, 'admin@gmail.com', 0, 'Asd@12345', ''),
(30, 'admin@gmail.com', 0, 'Asd@12345', ''),
(32, 'sanio1@gmail.com', 1, 'Sanio@1234', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_requestcourse`
--

CREATE TABLE `tbl_requestcourse` (
  `reqid` int(100) NOT NULL,
  `cid` int(100) NOT NULL,
  `stid` int(100) NOT NULL,
  `status` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_requestcourse`
--

INSERT INTO `tbl_requestcourse` (`reqid`, `cid`, `stid`, `status`) VALUES
(21, 14, 22, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_studentregister`
--

CREATE TABLE `tbl_studentregister` (
  `stid` int(50) NOT NULL,
  `logid` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `cpassword` varchar(50) NOT NULL,
  `stat` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_studentregister`
--

INSERT INTO `tbl_studentregister` (`stid`, `logid`, `name`, `course`, `gender`, `dob`, `phone`, `cpassword`, `stat`) VALUES
(10, 0, 'athira biju', 'science', 'female', '2022-09-30', '9048199815', '123', 0),
(16, 0, 'libiya', 'qq', 'female', '2022-09-02', '99999999', 'qwe', 0),
(30, 31, 'kkjkj', 'science', '', '2015-09-02', '9048199815', 'athirab1', 0),
(31, 32, 'Sanio', 'MCA', 'male', '2015-12-28', '+918692074192', 'Sanio@1234', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_courseadd`
--
ALTER TABLE `tbl_courseadd`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `tbl_requestcourse`
--
ALTER TABLE `tbl_requestcourse`
  ADD PRIMARY KEY (`reqid`);

--
-- Indexes for table `tbl_studentregister`
--
ALTER TABLE `tbl_studentregister`
  ADD PRIMARY KEY (`stid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_courseadd`
--
ALTER TABLE `tbl_courseadd`
  MODIFY `cid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `logid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tbl_requestcourse`
--
ALTER TABLE `tbl_requestcourse`
  MODIFY `reqid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbl_studentregister`
--
ALTER TABLE `tbl_studentregister`
  MODIFY `stid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

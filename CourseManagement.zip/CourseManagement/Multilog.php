<?php
session_start();
include('config.php');

if(isset($_POST['sub']))
{
  $email=$_POST["email"];
  $password=$_POST["password"];

  $sql="SELECT * from tbl_login where email='$email' and password='$password'";
  $result = mysqli_query($conn, $sql);


  if (mysqli_num_rows($result) > 0){

    foreach($result as $data)
    {
      $email=$data['email'];
      $password=$data['password'];
      $role=$data['role'];

    }
    $_SESSION['role']="$role";
    $_SESSION['email']="$email";
    $_SESSION['auth_user']=[
      'email'=>$email,
      'password'=>$password
    
	];

    if($_SESSION['role']=='admin')
    {
      $_SESSION['message']="Welcome";
      header("location:Adminpanel.html");
      exit(0);
    }
    else if($_SESSION['role']=='teacher')
    {
      $_SESSION['message']="Welcome";
       header("location:index.php");
      exit(0);
    }
    else if($_SESSION['role']=='designer')
    {
      $_SESSION['message']="Welcome";
       header("location:deshome.html");
      exit(0);
    }
}
else
{
    echo "Invalid Email ID/Password";
}
}
?>